package hm.edu.hafner.analysis;

public class Main {

    public int variable;

    public static void main(String... args) {
        int a=99;
        System.out.println("a");
        if(true)
            System.out.println("b");
        else {
            System.out.println("c");
        }
        return;
    }
}
